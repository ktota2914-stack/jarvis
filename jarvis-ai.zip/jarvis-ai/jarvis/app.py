"""Окно Джарвиса и главный цикл (wake-word «Джарвис»)."""
import difflib
import math
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk

from . import config, tools
from .brain import Brain
from .voice import Listener, Speaker

COLORS = {"idle": "#00d9ff", "listen": "#34f5a1", "think": "#ffb020", "speak": "#8c9cff"}
VOICES = ["ru-RU-DmitryNeural", "ru-RU-SvetlanaNeural"]


WAKE_ALT = {"чарвис", "джервис", "жарвис", "джарвиз", "джарви", "харвис"}


def split_wake(text: str):
    words = text.split()
    for i, w in enumerate(words[:3]):
        w = w.strip(",.!?")
        if w in WAKE_ALT or difflib.SequenceMatcher(None, w, "джарвис").ratio() >= 0.8:
            return True, " ".join(words[i + 1:])
    return False, text


class App:
    def __init__(self):
        self.cfg = config.load()
        self.brain = Brain(self.cfg)
        self.speaker = Speaker(self.cfg["voice"])
        self.listener = None
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.mic_on = True
        self.state = "idle"
        tools.register("look_screen", self.brain.describe_screen)
        tools.register("exit", self.quit)
        self._build_ui()
        threading.Thread(target=self._boot, daemon=True).start()

    # ---------- UI ----------
    def _build_ui(self):
        r = self.root = tk.Tk()
        r.title("J.A.R.V.I.S.")
        r.geometry("520x680")
        r.configure(bg="#05080f")
        r.protocol("WM_DELETE_WINDOW", self.quit)
        tk.Label(r, text="J.A.R.V.I.S.", fg="#00d9ff", bg="#05080f",
                 font=("Segoe UI", 22, "bold")).pack(pady=(14, 0))
        self.canvas = tk.Canvas(r, width=200, height=200, bg="#05080f", highlightthickness=0)
        self.canvas.pack()
        self.status = tk.Label(r, text="Запуск…", fg="#9fb4c8", bg="#05080f", font=("Segoe UI", 11))
        self.status.pack()
        self.log_box = tk.Text(r, height=18, bg="#0b1220", fg="#d6e2f0", bd=0, wrap="word",
                               font=("Segoe UI", 10), state="disabled", padx=8, pady=8)
        self.log_box.pack(fill="both", expand=True, padx=14, pady=10)
        row = tk.Frame(r, bg="#05080f")
        row.pack(fill="x", padx=14)
        self.entry = tk.Entry(row, bg="#0b1220", fg="#d6e2f0", insertbackground="#d6e2f0",
                              bd=0, font=("Segoe UI", 11))
        self.entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.entry.bind("<Return>", lambda e: self._send())
        ttk.Button(row, text="Отправить", command=self._send).pack(side="left", padx=(8, 0))
        row2 = tk.Frame(r, bg="#05080f")
        row2.pack(pady=10)
        self.mic_btn = ttk.Button(row2, text="🎤 Микрофон: вкл", command=self._toggle_mic)
        self.mic_btn.pack(side="left", padx=4)
        ttk.Button(row2, text="⚙ Настройки", command=self.open_settings).pack(side="left", padx=4)
        self.root.after(60, self._tick)

    def _tick(self):
        try:
            while True:
                kind, *a = self.q.get_nowait()
                if kind == "log":
                    self.log_box.config(state="normal")
                    self.log_box.insert("end", a[0] + "\n")
                    self.log_box.see("end")
                    self.log_box.config(state="disabled")
                elif kind == "status":
                    self.status.config(text=a[0])
                    self.state = a[1]
        except queue.Empty:
            pass
        pulse = 6 * math.sin(time.time() * (6 if self.state != "idle" else 2.5))
        rad = 52 + pulse
        c = COLORS.get(self.state, COLORS["idle"])
        self.canvas.delete("all")
        self.canvas.create_oval(100 - rad - 14, 100 - rad - 14, 100 + rad + 14, 100 + rad + 14,
                                outline=c, width=1)
        self.canvas.create_oval(100 - rad, 100 - rad, 100 + rad, 100 + rad, outline=c, width=3)
        self.canvas.create_oval(88, 88, 112, 112, fill=c, outline=c)
        self.root.after(60, self._tick)

    def log(self, s):
        self.q.put(("log", s))

    def set_status(self, s, state="idle"):
        self.q.put(("status", s, state))

    def _send(self):
        txt = self.entry.get().strip()
        if txt:
            self.entry.delete(0, "end")
            threading.Thread(target=self.handle, args=(txt,), daemon=True).start()

    def _toggle_mic(self):
        self.mic_on = not self.mic_on
        self.mic_btn.config(text="🎤 Микрофон: вкл" if self.mic_on else "🎤 Микрофон: выкл")

    def open_settings(self):
        w = tk.Toplevel(self.root)
        w.title("Настройки")
        w.geometry("440x260")
        w.configure(bg="#0b1220")
        key = tk.StringVar(value=self.cfg["gemini_api_key"])
        voice = tk.StringVar(value=self.cfg["voice"])
        local = tk.BooleanVar(value=self.cfg["use_local_llm"])
        tk.Label(w, text="Gemini API key:", bg="#0b1220", fg="#d6e2f0").pack(anchor="w", padx=14, pady=(14, 2))
        tk.Entry(w, textvariable=key, show="•", width=52).pack(padx=14)
        tk.Label(w, text="Голос:", bg="#0b1220", fg="#d6e2f0").pack(anchor="w", padx=14, pady=(12, 2))
        ttk.Combobox(w, textvariable=voice, values=VOICES, state="readonly").pack(anchor="w", padx=14)
        tk.Checkbutton(w, text="Офлайн-модель Qwen 2.5 0.5B", variable=local, bg="#0b1220", fg="#d6e2f0",
                       selectcolor="#0b1220", activebackground="#0b1220").pack(anchor="w", padx=14, pady=10)

        def save():
            self.cfg.update(gemini_api_key=key.get().strip(), voice=voice.get(), use_local_llm=local.get())
            config.save(self.cfg)
            self.brain.cfg = self.cfg
            self.speaker.voice = self.cfg["voice"]
            w.destroy()
            self.log("Настройки сохранены.")

        ttk.Button(w, text="Сохранить", command=save).pack(pady=8)

    # ---------- логика ----------
    def say(self, text):
        self.set_status("Говорю…", "speak")
        self.speaker.say(text)

    def confirm(self, tool_name) -> bool:
        if not self.listener:
            return False
        self.say("Подтвердите действие. Скажите «да» или «нет».")
        self.set_status("Жду подтверждения…", "listen")
        ans = self.listener.listen(timeout=6, limit=4)
        return any(w in ans.split() for w in ("да", "подтверждаю", "давай", "конечно"))

    def handle(self, cmd: str):
        with self.lock:
            self.log(f"Вы: {cmd}")
            self.set_status("Думаю…", "think")
            try:
                res = self.brain.process(cmd)
            except Exception as e:
                res = {"say": f"Произошла ошибка: {e}", "actions": []}
            if res.get("say"):
                self.log(f"Джарвис: {res['say']}")
                self.say(res["say"])
            for name, r in tools.execute(res.get("actions", []), confirm=self.confirm):
                if not r:
                    continue
                if name in tools.SPEAK:
                    self.log(f"Джарвис: {r}")
                    self.say(r)
                else:
                    self.log(f"· {r}")
                    if r.startswith(("Не нашёл", "Отменено")):
                        self.say(r)
            self.set_status("Жду «Джарвис»…", "idle")

    def _boot(self):
        try:
            self.listener = Listener()
        except Exception as e:
            self.log(f"Микрофон недоступен ({e}). Работает текстовый режим.")
        threading.Thread(target=self.brain.load_local, daemon=True).start()
        if not self.cfg["gemini_api_key"]:
            self.log("Gemini API key не задан — открой «Настройки». Пока работаю офлайн.")
        self.say("Системы запущены. Слушаю вас, сэр.")
        if not self.listener:
            self.set_status("Текстовый режим", "idle")
            return
        active_until = 0.0
        while True:
            if not self.mic_on:
                self.set_status("Микрофон выключен", "idle")
                time.sleep(0.4)
                continue
            self.set_status("Жду «Джарвис»…", "idle")
            text = self.listener.listen(timeout=5, limit=8)
            if not text:
                continue
            woke, cmd = split_wake(text)
            if not woke and time.time() > active_until:
                continue
            if woke and not cmd.strip():
                self.say("Слушаю, сэр.")
                self.set_status("Слушаю…", "listen")
                cmd = self.listener.listen(timeout=6, limit=10)
                if not cmd:
                    continue
            self.handle(cmd)
            active_until = time.time() + 10  # 10 с можно говорить без «Джарвис»

    def quit(self, *a):
        try:
            self.root.destroy()
        finally:
            os._exit(0)

    def run(self):
        self.root.mainloop()


def main():
    App().run()
