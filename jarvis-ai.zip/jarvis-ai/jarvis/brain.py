"""Мозг: правила -> Gemini (онлайн) -> Qwen 2.5 0.5B (офлайн)."""
import base64
import io
import json
import os
import re
import threading

from . import config, rules, tools

SYSTEM = """Ты — Джарвис, голосовой ИИ-ассистент в стиле дворецкого Тони Старка. Отвечай по-русски, кратко (1–2 предложения), вежливо, обращайся «сэр».
Управляешь компьютером пользователя с Windows через инструменты.
Отвечай СТРОГО одним JSON-объектом без пояснений:
{"say": "<что сказать вслух>", "actions": [{"tool": "<имя>", "args": {...}}]}
Если действие не нужно — "actions": []. Не выдумывай инструменты.
Инструменты:
{TOOLS}"""


def _system() -> str:
    doc = "\n".join(f"- {k}: {v}" for k, v in tools.TOOLS_DOC.items())
    return SYSTEM.replace("{TOOLS}", doc)


def parse(raw: str) -> dict:
    try:
        d = json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw or "", re.S)
        try:
            d = json.loads(m.group(0)) if m else {}
        except Exception:
            d = {}
        if not d:
            return {"say": (raw or "").strip(), "actions": []}
    acts = [a for a in d.get("actions", []) if isinstance(a, dict)
            and (a.get("tool") in tools.TOOLS or a.get("tool") in ("look_screen", "exit"))]
    return {"say": str(d.get("say", "")), "actions": acts}


class LocalLLM:
    def __init__(self):
        self.llm = None
        self.error = ""
        self._lock = threading.Lock()

    def load(self):
        path = config.find_model()
        if not path:
            self.error = "файл модели Qwen не найден"
            return
        try:
            from llama_cpp import Llama
            self.llm = Llama(model_path=str(path), n_ctx=2048,
                             n_threads=max(2, (os.cpu_count() or 4) // 2), verbose=False)
        except Exception as e:
            self.error = str(e)

    def ask(self, text: str) -> str:
        with self._lock:
            r = self.llm.create_chat_completion(
                messages=[{"role": "system", "content": _system()},
                          {"role": "user", "content": text}],
                response_format={"type": "json_object"}, temperature=0.3, max_tokens=220)
        return r["choices"][0]["message"]["content"]


class Brain:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.history = []
        self.local = LocalLLM()

    def load_local(self):
        if self.cfg.get("use_local_llm"):
            self.local.load()

    # --- Gemini ---
    def _gemini(self, contents, json_mode=True, system=True):
        import requests
        url = ("https://generativelanguage.googleapis.com/v1beta/models/"
               f"{self.cfg['gemini_model']}:generateContent")
        body = {"contents": contents, "generationConfig": {"temperature": 0.4}}
        if system:
            body["systemInstruction"] = {"parts": [{"text": _system()}]}
        if json_mode:
            body["generationConfig"]["responseMimeType"] = "application/json"
        r = requests.post(url, json=body, timeout=25,
                          headers={"x-goog-api-key": self.cfg["gemini_api_key"]})
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]

    def describe_screen(self, question: str = "Что на экране?") -> str:
        import pyautogui
        buf = io.BytesIO()
        pyautogui.screenshot().save(buf, format="PNG")
        img = base64.b64encode(buf.getvalue()).decode()
        contents = [{"role": "user", "parts": [
            {"inline_data": {"mime_type": "image/png", "data": img}},
            {"text": f"{question}\nОтветь по-русски, коротко, 1–3 предложения."}]}]
        return self._gemini(contents, json_mode=False, system=False)

    def process(self, text: str) -> dict:
        fast = rules.match(text)
        if fast:
            return fast
        if self.cfg.get("gemini_api_key"):
            try:
                contents = self.history[-8:] + [{"role": "user", "parts": [{"text": text}]}]
                raw = self._gemini(contents)
                self.history += [{"role": "user", "parts": [{"text": text}]},
                                 {"role": "model", "parts": [{"text": raw}]}]
                return parse(raw)
            except Exception:
                pass  # нет сети / ключ неверный -> офлайн-модель
        if self.local.llm:
            try:
                return parse(self.local.ask(text))
            except Exception as e:
                return {"say": f"Локальная модель дала сбой: {e}", "actions": []}
        return {"say": "Нет связи с Gemini, а локальная модель не загружена, сэр.", "actions": []}
