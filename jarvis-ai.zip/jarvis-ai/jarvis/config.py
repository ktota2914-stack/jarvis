import json
import os
import sys
from pathlib import Path

APP_DIR = Path(os.getenv("APPDATA") or Path.home()) / "JarvisAI"
APP_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_PATH = APP_DIR / "config.json"
MODEL_NAME = "qwen2.5-0.5b-instruct-q4_k_m.gguf"

DEFAULTS = {
    "gemini_api_key": "",
    "gemini_model": "gemini-2.5-flash",
    "voice": "ru-RU-DmitryNeural",
    "use_local_llm": True,
}


def resource_path(rel: str) -> Path:
    base = getattr(sys, "_MEIPASS", None) or Path(__file__).resolve().parent.parent
    return Path(base) / rel


def find_model():
    for p in (resource_path("models") / MODEL_NAME, APP_DIR / "models" / MODEL_NAME):
        if p.exists():
            return p
    return None


def load() -> dict:
    cfg = dict(DEFAULTS)
    try:
        cfg.update(json.loads(CONFIG_PATH.read_text("utf-8")))
    except Exception:
        pass
    if not cfg["gemini_api_key"]:
        cfg["gemini_api_key"] = os.getenv("GEMINI_API_KEY", "")
    return cfg


def save(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
