"""Быстрый распознаватель фраз: работает офлайн, без нейросети."""
import datetime
import re

MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
          "сентября", "октября", "ноября", "декабря"]
DAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]


def normalize(t: str) -> str:
    t = t.lower().replace("ё", "е")
    t = re.sub(r"[^\w\s%]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _r(say, *actions):
    return {"say": say, "actions": [{"tool": t, "args": a} for t, a in actions]}


def match(text: str):
    t = normalize(text)
    if not t:
        return None

    if re.search(r"\b(до свидания|отключись|завершить работу|выход)\b", t):
        return _r("До встречи, сэр.", ("exit", {}))
    if re.search(r"который час|сколько времени|сколько сейчас времени", t):
        return _r(f"Сейчас {datetime.datetime.now():%H:%M}, сэр.")
    if re.search(r"какое сегодня число|какая сегодня дата|какой сегодня день|какое число", t):
        d = datetime.date.today()
        return _r(f"Сегодня {DAYS[d.weekday()]}, {d.day} {MONTHS[d.month - 1]}.")

    if re.search(r"отмени (выключение|перезагрузку)", t):
        return _r("Отменяю.", ("cancel_shutdown", {}))
    if re.search(r"(выключи|отключи|заверши работу) (компьютер|пк|систему)", t):
        return _r("Выключаю компьютер.", ("shutdown_pc", {}))
    if re.search(r"перезагрузи (компьютер|пк|систему)|перезагрузка", t):
        return _r("Перезагружаю.", ("restart_pc", {}))
    if re.search(r"заблокируй", t):
        return _r("Блокирую, сэр.", ("lock_pc", {}))
    if "скриншот" in t or "снимок экрана" in t:
        return _r("Делаю снимок.", ("screenshot", {}))
    if re.search(r"сверни (все|окна)|покажи рабочий стол", t):
        return _r("Готово.", ("minimize_all", {}))

    m = re.search(r"громкость (?:на )?(\d{1,3})", t)
    if m:
        return _r("Хорошо.", ("set_volume", {"percent": int(m.group(1))}))
    if re.search(r"громче|прибавь звук|увеличь громкость", t):
        return _r("Громче.", ("volume_change", {"steps": 5}))
    if re.search(r"тише|убавь звук|уменьши громкость", t):
        return _r("Тише.", ("volume_change", {"steps": -5}))
    if re.search(r"без звука|выключи звук|отключи звук|включи звук", t):
        return _r("Хорошо.", ("mute", {}))
    if re.search(r"следующий трек|следующая песня|дальше", t):
        return _r("", ("media", {"action": "next"}))
    if re.search(r"предыдущий трек|предыдущая песня|назад", t):
        return _r("", ("media", {"action": "prev"}))
    if re.search(r"^(пауза|стоп|продолжи|играй|поставь на паузу)$", t):
        return _r("", ("media", {"action": "playpause"}))

    m = re.search(r"(?:найди|поищи|загугли|погугли)(?: в интернете| в гугле)? (.+)", t)
    if m:
        return _r("Ищу.", ("web_search", {"query": m.group(1)}))
    m = re.match(r"(?:напиши|набери|напечатай) (.+)", t)
    if m:
        return _r("", ("type_text", {"text": m.group(1)}))
    m = re.match(r"(?:открой|запусти|открыть|запустить|включи) (.+)", t)
    if m:
        return _r("", ("open_app", {"name": m.group(1)}))
    m = re.match(r"(?:закрой|закрыть|выключи) (.+)", t)
    if m:
        return _r("", ("close_app", {"name": m.group(1)}))
    return None
