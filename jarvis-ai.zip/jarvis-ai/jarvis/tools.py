"""Инструменты управления ПК (Windows)."""
import datetime
import difflib
import json
import os
import re
import subprocess
import sys
import webbrowser
from pathlib import Path
from urllib.parse import quote_plus

IS_WIN = sys.platform == "win32"
NOWIN = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW

_RU = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
_EN = ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p",
       "r", "s", "t", "u", "f", "kh", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]
_TR = dict(zip(_RU, _EN))


def translit(s: str) -> str:
    return "".join(_TR.get(c, c) for c in s.lower())


WEB = {
    "ютуб": "https://www.youtube.com", "youtube": "https://www.youtube.com",
    "гугл": "https://www.google.com", "google": "https://www.google.com",
    "браузер": "https://www.google.com", "вк": "https://vk.com", "вконтакте": "https://vk.com",
    "почта": "https://mail.google.com", "гитхаб": "https://github.com",
}
ALIASES = {
    "блокнот": "notepad", "калькулятор": "calc", "проводник": "explorer",
    "диспетчер задач": "taskmgr", "командная строка": "cmd", "пейнт": "mspaint",
    "настройки": "ms-settings:", "параметры": "ms-settings:", "панель управления": "control",
    "хром": "chrome", "гугл хром": "chrome", "эдж": "msedge",
    "ворд": "winword", "эксель": "excel", "паверпоинт": "powerpnt",
}
PROCS = {
    "хром": "chrome", "гугл хром": "chrome", "эдж": "msedge", "блокнот": "notepad",
    "калькулятор": "calculator", "пейнт": "mspaint", "ворд": "winword", "эксель": "excel",
    "диспетчер задач": "taskmgr",
}
PROTECTED = {"explorer", "system", "svchost", "csrss", "winlogon", "services", "lsass",
             "smss", "wininit", "dwm", "python", "jarvis"}
DANGEROUS = {"shutdown_pc", "restart_pc"}
SPEAK = {"look_screen"}  # результат этих инструментов озвучивается

_FILLER = re.compile(r"\b(приложение|программу|программа|пожалуйста|мне|пж)\b")


def _clean(name: str) -> str:
    return re.sub(r"\s+", " ", _FILLER.sub("", name.lower().replace("ё", "е"))).strip()


# ---------- запуск приложений ----------
_APPS = None


def _apps() -> dict:
    global _APPS
    if _APPS is not None:
        return _APPS
    idx = {}
    if IS_WIN:
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-StartApps | ConvertTo-Json -Compress"],
                capture_output=True, timeout=30, creationflags=NOWIN)
            data = json.loads(out.stdout.decode("utf-8", "ignore") or "[]")
            if isinstance(data, dict):
                data = [data]
            for a in data:
                idx[a["Name"].lower().replace("ё", "е")] = ("appid", a["AppID"])
        except Exception:
            pass
        for d in (os.path.expandvars(r"%ProgramData%\Microsoft\Windows\Start Menu\Programs"),
                  os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs")):
            for root, _, files in os.walk(d):
                for f in files:
                    if f.lower().endswith((".lnk", ".url")):
                        idx.setdefault(Path(f).stem.lower().replace("ё", "е"), ("path", os.path.join(root, f)))
    _APPS = idx
    return idx


def _find(n: str):
    idx = _apps()
    if not idx or not n:
        return None
    if n in idx:
        return idx[n]
    tn = translit(n)
    tkeys = {translit(k): k for k in idx}
    for tk, k in tkeys.items():
        if tn in tk or (tk in tn and len(tk) >= 4):
            return idx[k]
    m = difflib.get_close_matches(tn, list(tkeys), n=1, cutoff=0.6)
    return idx[tkeys[m[0]]] if m else None


def _start(target: str):
    if target.startswith("http"):
        webbrowser.open(target)
    else:
        subprocess.Popen(["cmd", "/c", "start", "", target], creationflags=NOWIN)


def open_app(name: str) -> str:
    n = _clean(name)
    if n in WEB:
        webbrowser.open(WEB[n])
        return f"Открываю {name}"
    if n in ALIASES:
        _start(ALIASES[n])
        return f"Запускаю {name}"
    hit = _find(n)
    if hit:
        kind, val = hit
        if kind == "appid":
            subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + val])
        else:
            os.startfile(val)
        return f"Запускаю {name}"
    return f"Не нашёл приложение «{name}»"


def close_app(name: str) -> str:
    import psutil
    n = _clean(name)
    key = PROCS.get(n) or translit(n).replace(" ", "")
    if len(key) < 3:
        return "Не понял, что закрыть"
    killed = 0
    for p in psutil.process_iter(["name"]):
        pn = (p.info["name"] or "").lower()
        pn = pn[:-4] if pn.endswith(".exe") else pn
        if pn in PROTECTED:
            continue
        if key in pn.replace(" ", ""):
            try:
                p.terminate()
                killed += 1
            except Exception:
                pass
    return f"Закрыл {name}" if killed else f"Не нашёл запущенное «{name}»"


def open_url(url: str) -> str:
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    return "Открываю сайт"


def web_search(query: str) -> str:
    webbrowser.open("https://www.google.com/search?q=" + quote_plus(query))
    return f"Ищу: {query}"


# ---------- ввод и управление ----------
def _pg():
    import pyautogui
    pyautogui.PAUSE = 0.05
    return pyautogui


def type_text(text: str) -> str:
    import pyperclip
    pyperclip.copy(text)  # через буфер, чтобы работала кириллица
    _pg().hotkey("ctrl", "v")
    return "Напечатал"


def press_keys(keys) -> str:
    if isinstance(keys, str):
        keys = [k.strip() for k in re.split(r"[+,]", keys) if k.strip()]
    _pg().hotkey(*[str(k).lower() for k in keys])
    return "Готово"


def click(x: int, y: int, button: str = "left", double: bool = False) -> str:
    pg = _pg()
    pg.click(int(x), int(y), clicks=2 if double else 1, button=button)
    return "Кликнул"


def scroll(amount: int) -> str:
    _pg().scroll(int(amount))
    return "Прокрутил"


def minimize_all() -> str:
    _pg().hotkey("win", "d")
    return "Готово"


def set_volume(percent: int) -> str:
    pg = _pg()
    pg.press("volumedown", presses=50, interval=0)
    pg.press("volumeup", presses=max(0, min(100, int(percent))) // 2, interval=0)
    return f"Громкость {percent}%"


def volume_change(steps: int) -> str:
    steps = int(steps)
    _pg().press("volumeup" if steps > 0 else "volumedown", presses=abs(steps), interval=0)
    return "Готово"


def mute() -> str:
    _pg().press("volumemute")
    return "Готово"


def media(action: str) -> str:
    key = {"playpause": "playpause", "next": "nexttrack", "prev": "prevtrack"}.get(action, "playpause")
    _pg().press(key)
    return "Готово"


def screenshot() -> str:
    folder = Path.home() / "Pictures"
    folder.mkdir(exist_ok=True)
    path = folder / f"Jarvis_{datetime.datetime.now():%Y%m%d_%H%M%S}.png"
    _pg().screenshot().save(path)
    return f"Скриншот сохранён: {path.name}"


# ---------- система ----------
def lock_pc() -> str:
    import ctypes
    ctypes.windll.user32.LockWorkStation()
    return "Блокирую"


def shutdown_pc() -> str:
    subprocess.Popen(["shutdown", "/s", "/t", "15"], creationflags=NOWIN)
    return "Выключение через 15 секунд. Скажите «отмени выключение», чтобы остановить."


def restart_pc() -> str:
    subprocess.Popen(["shutdown", "/r", "/t", "15"], creationflags=NOWIN)
    return "Перезагрузка через 15 секунд."


def cancel_shutdown() -> str:
    subprocess.Popen(["shutdown", "/a"], creationflags=NOWIN)
    return "Отменено"


TOOLS = {
    "open_app": open_app, "close_app": close_app, "open_url": open_url, "web_search": web_search,
    "type_text": type_text, "press_keys": press_keys, "click": click, "scroll": scroll,
    "minimize_all": minimize_all, "set_volume": set_volume, "volume_change": volume_change,
    "mute": mute, "media": media, "screenshot": screenshot, "lock_pc": lock_pc,
    "shutdown_pc": shutdown_pc, "restart_pc": restart_pc, "cancel_shutdown": cancel_shutdown,
}

TOOLS_DOC = {
    "open_app": 'открыть приложение или сайт: {"name": "телеграм"}',
    "close_app": 'закрыть приложение: {"name": "хром"}',
    "open_url": 'открыть ссылку: {"url": "https://..."}',
    "web_search": 'поиск в интернете: {"query": "..."}',
    "type_text": 'напечатать текст в активном окне: {"text": "..."}',
    "press_keys": 'нажать сочетание клавиш: {"keys": ["ctrl", "c"]}',
    "click": 'клик мышью по координатам экрана: {"x": 100, "y": 200}',
    "scroll": 'прокрутка (положительное — вверх): {"amount": -300}',
    "minimize_all": "свернуть все окна: {}",
    "set_volume": 'громкость 0-100: {"percent": 40}',
    "volume_change": 'шаги громкости (+ громче, - тише): {"steps": 5}',
    "mute": "вкл/выкл звук: {}",
    "media": 'медиа: {"action": "playpause" | "next" | "prev"}',
    "screenshot": "сделать скриншот: {}",
    "lock_pc": "заблокировать ПК: {}",
    "shutdown_pc": "выключить ПК: {}",
    "restart_pc": "перезагрузить ПК: {}",
    "cancel_shutdown": "отменить выключение: {}",
    "look_screen": 'посмотреть на экран и ответить на вопрос: {"question": "..."}',
    "exit": "закрыть Джарвиса: {}",
}


def register(name: str, fn) -> None:
    TOOLS[name] = fn


def execute(actions: list, confirm=None) -> list:
    results = []
    for a in actions:
        name = a.get("tool")
        fn = TOOLS.get(name)
        if not fn:
            continue
        if name in DANGEROUS and not (confirm and confirm(name)):
            results.append((name, "Отменено"))
            continue
        try:
            r = fn(**(a.get("args") or {}))
        except Exception as e:
            r = f"Ошибка {name}: {e}"
        results.append((name, r))
    return results
