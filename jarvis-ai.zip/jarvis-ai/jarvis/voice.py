"""Голос (edge-tts, запасной вариант — SAPI) и распознавание русской речи."""
import asyncio
import os
import tempfile
import threading

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


class Speaker:
    def __init__(self, voice: str):
        self.voice = voice
        self._lock = threading.Lock()

    def say(self, text: str) -> None:
        if not text:
            return
        with self._lock:
            try:
                self._edge(text)
            except Exception:
                try:
                    self._offline(text)
                except Exception:
                    pass

    def _edge(self, text: str) -> None:
        import edge_tts
        import pygame
        path = os.path.join(tempfile.gettempdir(), f"jarvis_{os.getpid()}.mp3")

        async def run():
            # чуть ниже тон и быстрее темп — «деловой» голос Джарвиса
            await edge_tts.Communicate(text, self.voice, rate="+6%", pitch="-8Hz").save(path)

        asyncio.run(run())
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        pygame.mixer.music.load(path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.wait(40)
        pygame.mixer.music.unload()

    def _offline(self, text: str) -> None:
        import pyttsx3
        eng = pyttsx3.init()
        for v in eng.getProperty("voices"):
            if any(k in (v.name or "").lower() for k in ("pavel", "irina", "russian", "ru-")):
                eng.setProperty("voice", v.id)
                break
        eng.setProperty("rate", 185)
        eng.say(text)
        eng.runAndWait()


class Listener:
    def __init__(self):
        import speech_recognition as sr
        self.sr = sr
        self.r = sr.Recognizer()
        self.r.pause_threshold = 0.8
        self.r.dynamic_energy_threshold = True
        self.mic = sr.Microphone()
        with self.mic as src:
            self.r.adjust_for_ambient_noise(src, duration=0.6)

    def listen(self, timeout=None, limit=10) -> str:
        sr = self.sr
        with self.mic as src:
            try:
                audio = self.r.listen(src, timeout=timeout, phrase_time_limit=limit)
            except sr.WaitTimeoutError:
                return ""
        try:
            return self.r.recognize_google(audio, language="ru-RU").lower()
        except (sr.UnknownValueError, sr.RequestError):
            return ""
